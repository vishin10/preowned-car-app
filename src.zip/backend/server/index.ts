import express, { Request, Response } from 'express';
import cors from 'cors';
import axios from 'axios';

import uploadRoutes from './upload';
import { db } from './firebaseAdmin';

const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

app.use('/api', uploadRoutes);

app.post('/api/admin/add-vehicle', async (req: Request, res: Response) => {
  try {
    const {
      make,
      model,
      year,
      price,
      mileage,
      fuelType,
      transmission,
      engineSize,
      color,
      features,
      description,
      bodyType,
      condition,
      imageUrl,
    } = req.body;

    if (!imageUrl) {
      return res.status(400).json({ error: 'Image URL missing' });
    }

    const vehicleData = {
      make,
      model,
      year: Number(year),
      price: Number(price),
      mileage: Number(mileage),
      fuelType,
      transmission,
      engineSize,
      color,
      features: typeof features === 'string' ? features.split(',').map(f => f.trim()) : features,
      description,
      bodyType,
      condition: condition || 'used',
      sold: false,
      images: [imageUrl],
    };

    const result = await db.collection('vehicles').add(vehicleData);
    res.status(201).json({ id: result.id });
  } catch (err) {
    console.error("❌ Firestore Error:", err);
    res.status(500).json({ error: 'Failed to save vehicle' });
  }
});

app.get('/api/google-reviews', async (req, res) => {
  try {
    const response = await axios.get('https://maps.googleapis.com/maps/api/place/details/json', {
      params: {
        place_id: 'ChIJacPtUmWJyIkRDCwymLIfASY',
        fields: 'name,rating,reviews',
        key: 'AIzaSyDIF4xN9RDsW95v21Op7VOMYAKVMuQeX2g',
      },
    });

    const reviews = response.data.result?.reviews || [];
    const fiveStar = reviews.filter((r: any) => r.rating === 5);

    res.json(fiveStar);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch reviews' });
  }
});

app.listen(PORT, () => {
  console.log(`✅ Backend running at http://localhost:${PORT}`);
});
